/* package com.example.borsatakipuygulamasi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BorsaIstanbulActivity extends AppCompatActivity {

    // Değişkenler
    private EditText etHisseAdi, etMaliyet, etStopNoktasi, etNot;
    private TextView tvTakipListesi;
    private SharedPreferences sharedPreferences; // SharedPreferences tanımı
    private static final String PREF_NAME = "HisseTakipPrefs"; // SharedPreferences adı
    private static final String LIST_KEY = "HisseListesi"; // Anahtar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borsa_istanbul);

        // Görselleri bağlama
        etHisseAdi = findViewById(R.id.etHisseAdi);
        etMaliyet = findViewById(R.id.etMaliyet);
        etStopNoktasi = findViewById(R.id.etStopNoktasi);
        etNot = findViewById(R.id.etNot);
        tvTakipListesi = findViewById(R.id.tvTakipListesi);
        Button btnEkle = findViewById(R.id.btnEkle);

        // SharedPreferences başlat
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Önceden kaydedilmiş veriyi yükle
        loadSavedData();

        // "Ekle" butonuna tıklanma olayını tanımlama
        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kullanıcıdan gelen verileri al
                String hisseAdi = etHisseAdi.getText().toString();
                String maliyet = etMaliyet.getText().toString();
                String stopNoktasi = etStopNoktasi.getText().toString();
                String not = etNot.getText().toString();

                // Boş alan kontrolü
                if (hisseAdi.isEmpty() || maliyet.isEmpty() || stopNoktasi.isEmpty() || not.isEmpty()) {
                    tvTakipListesi.setText("Lütfen tüm alanları doldurun.");
                    return;
                }

                // Yeni hisse bilgilerini oluştur
                String yeniHisse = "Hisse: " + hisseAdi + "\n"
                        + "Maliyet: " + maliyet + "\n"
                        + "Stop Noktası: " + stopNoktasi + "\n"
                        + "Beklentiler: " + not + "\n\n";

                // Önceki listeyi al ve yeni veriyi ekle
                String mevcutListe = tvTakipListesi.getText().toString();
                String guncelListe = mevcutListe + yeniHisse;

                // Listeyi ekrana yazdır
                tvTakipListesi.setText(guncelListe);

                // Veriyi kaydet
                saveData(guncelListe);

                // Formu sıfırla
                etHisseAdi.setText("");
                etMaliyet.setText("");
                etStopNoktasi.setText("");
                etNot.setText("");
            }
        });

        // Geri düğmesini etkinleştir
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    // SharedPreferences ile veriyi kaydetme
    private void saveData(String data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(LIST_KEY, data);
        editor.apply();
    }

    // SharedPreferences'ten veriyi yükleme
    private void loadSavedData() {
        String savedList = sharedPreferences.getString(LIST_KEY, ""); // Varsayılan boş
        tvTakipListesi.setText(savedList);
    }

    // Geri düğmesine basıldığında aktiviteyi kapat
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
} */


package com.example.borsatakipuygulamasi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BorsaIstanbulActivity extends AppCompatActivity {

    // Değişkenler
    private EditText etHisseAdi, etMaliyet, etStopNoktasi, etNot;
    private TextView tvTakipListesi;
    private SharedPreferences sharedPreferences; // SharedPreferences tanımı
    private static final String PREF_NAME = "HisseTakipPrefs"; // SharedPreferences adı
    private static final String LIST_KEY = "HisseListesi"; // Anahtar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borsa_istanbul);

        // Görselleri bağlama
        etHisseAdi = findViewById(R.id.etHisseAdi);
        etMaliyet = findViewById(R.id.etMaliyet);
        etStopNoktasi = findViewById(R.id.etStopNoktasi);
        etNot = findViewById(R.id.etNot);
        tvTakipListesi = findViewById(R.id.tvTakipListesi);
        Button btnEkle = findViewById(R.id.btnEkle);
        Button btnListeyiSil = findViewById(R.id.button); // Listeyi Sil butonunun referansı

        // SharedPreferences başlat
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Önceden kaydedilmiş veriyi yükle
        loadSavedData();

        // "Ekle" butonuna tıklanma olayını tanımlama
        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kullanıcıdan gelen verileri al
                String hisseAdi = etHisseAdi.getText().toString();
                String maliyet = etMaliyet.getText().toString();
                String stopNoktasi = etStopNoktasi.getText().toString();
                String not = etNot.getText().toString();

                // Boş alan kontrolü
                if (hisseAdi.isEmpty() || maliyet.isEmpty() || stopNoktasi.isEmpty() || not.isEmpty()) {
                    tvTakipListesi.setText("Lütfen tüm alanları doldurun.");
                    return;
                }

                // Yeni hisse bilgilerini oluştur
                String yeniHisse = "Hisse: " + hisseAdi + "\n"
                        + "Maliyet: " + maliyet + "\n"
                        + "Stop Noktası: " + stopNoktasi + "\n"
                        + "Beklentiler: " + not + "\n\n";

                // Önceki listeyi al ve yeni veriyi ekle
                String mevcutListe = tvTakipListesi.getText().toString();
                String guncelListe = mevcutListe + yeniHisse;

                // Listeyi ekrana yazdır
                tvTakipListesi.setText(guncelListe);

                // Veriyi kaydet
                saveData(guncelListe);

                // Formu sıfırla
                etHisseAdi.setText("");
                etMaliyet.setText("");
                etStopNoktasi.setText("");
                etNot.setText("");
            }
        });

        // Listeyi Sil butonuna tıklanma olayını tanımlama
        btnListeyiSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Takip listesini temizle
                tvTakipListesi.setText("");

                // SharedPreferences'den veriyi sil
                clearData();
            }
        });

        // Geri düğmesini etkinleştir
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    // SharedPreferences ile veriyi kaydetme
    private void saveData(String data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(LIST_KEY, data);
        editor.apply();
    }

    // SharedPreferences'ten veriyi yükleme
    private void loadSavedData() {
        String savedList = sharedPreferences.getString(LIST_KEY, ""); // Varsayılan boş
        tvTakipListesi.setText(savedList);
    }

    // SharedPreferences'teki veriyi silme
    private void clearData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(LIST_KEY); // LIST_KEY anahtarını kullanarak veriyi sil
        editor.apply();
    }

    // Geri düğmesine basıldığında aktiviteyi kapat
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
