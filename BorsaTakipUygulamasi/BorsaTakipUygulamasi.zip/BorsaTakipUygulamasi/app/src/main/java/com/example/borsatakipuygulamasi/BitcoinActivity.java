

package com.example.borsatakipuygulamasi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BitcoinActivity extends AppCompatActivity {

    private EditText etBitcoinAdi, etMaliyet, etStopNoktasi, etNot;
    private TextView tvBitcoinListesi;
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "BitcoinTakipPrefs";
    private static final String LIST_KEY = "BitcoinListesi";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bitcoin); // Yeni XML layout'u

        etBitcoinAdi = findViewById(R.id.etBitcoinAdi);
        etMaliyet = findViewById(R.id.etMaliyet);
        etStopNoktasi = findViewById(R.id.etStopNoktasi);
        etNot = findViewById(R.id.etNot);
        tvBitcoinListesi = findViewById(R.id.tvBitcoinListesi);
        Button btnEkle = findViewById(R.id.btnEkle);
        Button btnListeyiSil = findViewById(R.id.button2); // Listeyi Sil butonu

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Kaydedilen verileri yükle
        loadSavedData();

        // Ekle butonuna tıklanma olayını tanımla
        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bitcoinAdi = etBitcoinAdi.getText().toString();
                String maliyet = etMaliyet.getText().toString();
                String stopNoktasi = etStopNoktasi.getText().toString();
                String not = etNot.getText().toString();

                if (bitcoinAdi.isEmpty() || maliyet.isEmpty() || stopNoktasi.isEmpty() || not.isEmpty()) {
                    tvBitcoinListesi.setText("Lütfen tüm alanları doldurun.");
                    return;
                }

                String yeniBitcoin = "Bitcoin: " + bitcoinAdi + "\n"
                        + "Maliyet: " + maliyet + "\n"
                        + "Stop Noktası: " + stopNoktasi + "\n"
                        + "Beklentiler: " + not + "\n\n";

                String mevcutListe = tvBitcoinListesi.getText().toString();
                String guncelListe = mevcutListe + yeniBitcoin;

                tvBitcoinListesi.setText(guncelListe);

                saveData(guncelListe);

                // Formu sıfırla
                etBitcoinAdi.setText("");
                etMaliyet.setText("");
                etStopNoktasi.setText("");
                etNot.setText("");
            }
        });

        // Listeyi Sil butonuna tıklanma olayını tanımla
        btnListeyiSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Takip listesini temizle
                tvBitcoinListesi.setText("");

                // SharedPreferences'den veriyi sil
                clearData();
            }
        });

        // Geri düğmesini etkinleştir
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    // Veriyi SharedPreferences'e kaydetme
    private void saveData(String data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(LIST_KEY, data);
        editor.apply();
    }

    // Kaydedilen veriyi yükleme
    private void loadSavedData() {
        String savedList = sharedPreferences.getString(LIST_KEY, ""); // Varsayılan boş değer
        tvBitcoinListesi.setText(savedList);
    }

    // SharedPreferences'teki veriyi silme
    private void clearData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(LIST_KEY); // LIST_KEY anahtarını kullanarak veriyi sil
        editor.apply();
    }

    // Geri düğmesine basıldığında aktiviteyi kapat
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
